//
//  Note+CoreDataProperties.swift
//  NotepadV2
//
//  Created by Alex Cowley on 10/25/15.
//  Copyright © 2015 Alex Cowley. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Note {

    @NSManaged var content: String?

}
