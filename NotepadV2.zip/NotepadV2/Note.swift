//
//  Note.swift
//  NotepadV2
//
//  Created by Alex Cowley on 10/25/15.
//  Copyright © 2015 Alex Cowley. All rights reserved.
//

import Foundation
import CoreData


class Note: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
