//
//  DetailViewController.swift
//  NotepadV2
//
//  Created by Alex Cowley on 10/22/15.
//  Copyright © 2015 Alex Cowley. All rights reserved.
//

import UIKit
import CoreData

class DetailViewController: UIViewController {

    @IBOutlet weak var TextBox: UITextView!
    
    var MOC: NSManagedObjectContext!
    var note: Note? = nil
   
    override func viewDidLoad() {
        if note != nil {
        TextBox.text = note!.valueForKey("content") as! String
        }
    }
    //when leaving textbox(detailview) view update the notes array in tableview
    override func viewDidDisappear(animated: Bool) {
        if note == nil {
            let note = NSEntityDescription.insertNewObjectForEntityForName("Note", inManagedObjectContext: MOC) as! Note
        }
          note!.content = TextBox.text
            do {
                try MOC.save()
            } catch {
                let e = error as NSError
                print("failed \(e.localizedDescription)")
                
            }
        
    }
    
    
}