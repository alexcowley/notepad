//
//  ViewController.swift
//  NotepadV2
//
//  Created by Alex Cowley on 10/22/15.
//  Copyright © 2015 Alex Cowley. All rights reserved.
//

import UIKit

public var notes = [String]()
public var currentindex = 0

class ViewController: UIViewController {
    
    //Add Button
    @IBAction func AddButtonPressed(sender: UIBarButtonItem) {
        notes.append(String())
        currentindex = notes.count-1
        let detailview = storyboard!.instantiateViewControllerWithIdentifier("Detail View") as! DetailViewController
        showViewController(detailview, sender: self)
        
    }
    
    //Add edit button in top left
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.leftBarButtonItem = self.editButtonItem()
        
    }

  
    override func viewDidAppear(animated: Bool) {
        self.tableView.reloadData()
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //Number of sections added in table view
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    //Number of rows in the section of the table view
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return notes.count
    }
    
    //Creates cell for table view
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
        cell.textLabel!.text = notes[indexPath.row]
        
        return cell
    }
    
    //when row is selected index is updated
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        currentindex = indexPath.row
    }
    
    
    
    //Delete functionality
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            notes.removeAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }



}

